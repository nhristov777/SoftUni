﻿namespace SoftUniKindergarten
{
    public class StartUp
    {
        static void Main()
        {
            
        }
    }
}